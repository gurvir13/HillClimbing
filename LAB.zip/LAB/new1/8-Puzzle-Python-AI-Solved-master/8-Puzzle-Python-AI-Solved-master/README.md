# 8-Puzzle-Python-AI-Solved
To run this code: python searcher.py strategy
  With startegy = dfs, bfs, hc, sahc, astar
  Ex: python searcher.py astar
